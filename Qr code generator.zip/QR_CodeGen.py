import qrcode as qr
img=qr.make("https://github.com/apoorva-18/apoorva-18")
img.save("Github_Acc.png")
